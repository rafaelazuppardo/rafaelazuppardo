import { Mail, Phone, Instagram, Linkedin } from 'lucide-react';

export function Footer() {
  return (
    <footer id="contato" className="bg-primary text-primary-foreground py-16 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 right-0 w-96 h-96 bg-secondary rounded-full blur-3xl"></div>
      </div>
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          <div className="space-y-4">
            <h3 className="text-2xl tracking-tight">
              Rafaela Zuppardo
            </h3>
            <p className="text-primary-foreground/80 leading-relaxed">
              Autoconhecimento, terapias integrativas e cuidado consciente.
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="text-lg">Contato</h4>
            <div className="space-y-3">
              <a
                href="mailto:contato@rafaelazuppardo.com.br"
                className="flex items-center gap-3 text-primary-foreground/80 hover:text-secondary transition-colors"
              >
                <Mail size={20} />
                <span>contato@rafaelazuppardo.com.br</span>
              </a>
              <a
                href="tel:+5511999999999"
                className="flex items-center gap-3 text-primary-foreground/80 hover:text-secondary transition-colors"
              >
                <Phone size={20} />
                <span>(11) 99999-9999</span>
              </a>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-lg">Redes Sociais</h4>
            <div className="flex gap-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-primary-foreground/10 rounded-full hover:bg-secondary transition-all"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-primary-foreground/10 rounded-full hover:bg-secondary transition-all"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-primary-foreground/20 text-center text-sm text-primary-foreground/60">
          <p>&copy; {new Date().getFullYear()} Rafaela Zuppardo. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
