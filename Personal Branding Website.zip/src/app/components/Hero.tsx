import { ImageWithFallback } from './ImageWithFallback';
import { motion } from 'motion/react';

export function Hero() {
  return (
    <section id="hero" className="min-h-screen flex items-center pt-20">
      <div className="container mx-auto px-4 md:px-6 py-12 md:py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <div className="inline-block px-4 py-2 bg-accent rounded-full">
              <span className="text-sm tracking-wide text-primary">Cuidado Integral e Humanizado</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl tracking-tight text-primary">
              Rafaela Zuppardo
            </h1>

            <p className="text-lg md:text-xl text-foreground/80">
              Terapeuta, Doula de Fim de Vida e Educadora
            </p>

            <p className="text-base md:text-lg leading-relaxed text-foreground/70">
              Acompanho processos de autoconhecimento, desenvolvimento pessoal e
              transições da vida através de terapias integrativas e cuidado humanizado.
              Formando profissionais comprometidos com o cuidado consciente e transformador.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button
                onClick={() => document.getElementById('contato')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all shadow-md hover:shadow-lg"
              >
                Entre em Contato
              </button>
              <button
                onClick={() => document.getElementById('sobre')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 bg-white text-primary border-2 border-primary rounded-lg hover:bg-accent transition-all"
              >
                Saiba Mais
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-secondary/20 rounded-3xl transform rotate-3"></div>
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1612277795009-f95f2e8c4a02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw0fHxoZWFsdGhjYXJlJTIwcHJvZmVzc2lvbmFsJTIwY2FyaW5nJTIwY29tcGFzc2lvbmF0ZXxlbnwxfHx8fDE3Nzk2NTQ5Nzl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Profissional de saúde em atendimento"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
