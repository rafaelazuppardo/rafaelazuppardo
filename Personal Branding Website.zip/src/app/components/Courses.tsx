import { ImageWithFallback } from './ImageWithFallback';
import { FadeIn } from './FadeIn';
import { Clock, Users, Award } from 'lucide-react';

const courses = [
  {
    title: 'Formação em Terapias Integrativas',
    description: 'Curso completo para quem deseja atuar como terapeuta holístico com foco em autoconhecimento e transformação.',
    duration: '120 horas',
    students: '200+',
    image: 'https://images.unsplash.com/photo-1600618528240-fb9fc964b853?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob2xpc3RpYyUyMHRoZXJhcHklMjB3ZWxsbmVzcyUyMGhlYWxpbmd8ZW58MXx8fHwxNzc5NjU0OTgwfDA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  {
    title: 'Doula de Fim de Vida',
    description: 'Formação profunda sobre acompanhamento compassivo nos processos de transição e luto.',
    duration: '60 horas',
    students: '150+',
    image: 'https://images.unsplash.com/photo-1611073615830-9f76902c10fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw1fHxob2xpc3RpYyUyMHRoZXJhcHklMjB3ZWxsbmVzcyUyMGhlYWxpbmd8ZW58MXx8fHwxNzc5NjU0OTgwfDA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  {
    title: 'Autoconhecimento e Desenvolvimento Pessoal',
    description: 'Jornada intensiva de autodescoberta para terapeutas e pessoas em busca de transformação interior.',
    duration: '40 horas',
    students: '180+',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxob2xpc3RpYyUyMHRoZXJhcHklMjB3ZWxsbmVzcyUyMGhlYWxpbmd8ZW58MXx8fHwxNzc5NjU0OTgwfDA&ixlib=rb-4.1.0&q=80&w=1080'
  }
];

export function Courses() {
  return (
    <section id="cursos" className="py-20 bg-accent/20">
      <div className="container mx-auto px-4 md:px-6">
        <FadeIn>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl text-primary mb-4">
            Formações e Cursos
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Capacitação profissional para terapeutas, doulas e pessoas interessadas
            em práticas integrativas e desenvolvimento pessoal.
          </p>
          </div>
        </FadeIn>

        <div className="grid md:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <FadeIn key={course.title} delay={index * 0.1}>
            <div
              key={course.title}
              className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 group"
            >
              <div className="relative h-48 overflow-hidden">
                <ImageWithFallback
                  src={course.image}
                  alt={course.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent"></div>
              </div>

              <div className="p-6 space-y-4">
                <h3 className="text-xl text-primary">
                  {course.title}
                </h3>

                <p className="text-sm text-foreground/70 leading-relaxed">
                  {course.description}
                </p>

                <div className="flex items-center gap-4 pt-2">
                  <div className="flex items-center gap-2 text-sm text-foreground/60">
                    <Clock size={16} className="text-secondary" />
                    {course.duration}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-foreground/60">
                    <Users size={16} className="text-secondary" />
                    {course.students} alunos
                  </div>
                </div>

                <button className="w-full mt-4 px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all">
                  Saiba Mais
                </button>
              </div>
            </div>
            </FadeIn>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-secondary/20 rounded-full">
            <Award className="text-secondary" size={20} />
            <span className="text-primary">Certificação reconhecida</span>
          </div>
        </div>
      </div>
    </section>
  );
}
