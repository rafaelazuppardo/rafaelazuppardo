import { FadeIn } from './FadeIn';
import { ArrowRight } from 'lucide-react';

export function CTA() {
  return (
    <section className="py-20 bg-gradient-to-br from-primary to-primary/90 text-primary-foreground relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-secondary rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <FadeIn>
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl md:text-4xl lg:text-5xl">
            Vamos conversar sobre sua jornada?
          </h2>

          <p className="text-lg md:text-xl text-primary-foreground/90 leading-relaxed">
            Estou à disposição para esclarecer dúvidas sobre atendimentos, formações
            ou iniciarmos juntos um processo de autoconhecimento e transformação.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
            <button
              onClick={() => window.location.href = 'mailto:contato@rafaelazuppardo.com.br'}
              className="px-8 py-4 bg-white text-primary rounded-lg hover:bg-accent transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 group"
            >
              <span>Enviar E-mail</span>
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => window.location.href = 'https://wa.me/5511999999999'}
              className="px-8 py-4 bg-secondary text-primary rounded-lg hover:bg-secondary/90 transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
            >
              <span>WhatsApp</span>
            </button>
          </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
