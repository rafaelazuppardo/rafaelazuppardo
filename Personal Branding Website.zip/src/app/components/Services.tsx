import { FadeIn } from './FadeIn';
import { Stethoscope, Sparkles, Heart, GraduationCap } from 'lucide-react';

const services = [
  {
    icon: Sparkles,
    title: 'Terapias Integrativas',
    description: 'Sessões individuais que promovem autoconhecimento e equilíbrio através de práticas holísticas.',
    features: ['Terapia holística', 'Desenvolvimento pessoal', 'Ressignificação emocional']
  },
  {
    icon: Heart,
    title: 'Doula de Fim de Vida',
    description: 'Acompanhamento compassivo e respeitoso durante o processo de transição e luto.',
    features: ['Suporte emocional', 'Cuidado compassivo', 'Apoio à família']
  },
  {
    icon: GraduationCap,
    title: 'Formações Profissionais',
    description: 'Capacitação de terapeutas e profissionais de cuidado em práticas integrativas e conscientes.',
    features: ['Cursos especializados', 'Mentoria individual', 'Supervisão terapêutica']
  },
  {
    icon: Stethoscope,
    title: 'Consultoria',
    description: 'Orientação para desenvolvimento de projetos terapêuticos e cuidado humanizado.',
    features: ['Projetos personalizados', 'Assessoria técnica', 'Palestras e workshops']
  }
];

export function Services() {
  return (
    <section id="atuacao" className="py-20 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <FadeIn>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl text-primary mb-4">
            Serviços e Atuação
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Atendimentos e formações focados em autoconhecimento, desenvolvimento
            pessoal e cuidado consciente.
          </p>
          </div>
        </FadeIn>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <FadeIn key={service.title} delay={index * 0.1}>
              <div
                key={service.title}
                className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 border border-border hover:border-secondary group"
              >
                <div className="p-4 bg-accent rounded-xl w-fit mb-4 group-hover:bg-secondary/20 transition-colors">
                  <Icon className="text-primary" size={32} />
                </div>

                <h3 className="text-xl text-primary mb-3">
                  {service.title}
                </h3>

                <p className="text-sm text-foreground/70 mb-4 leading-relaxed">
                  {service.description}
                </p>

                <ul className="space-y-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-foreground/60">
                      <div className="w-1.5 h-1.5 rounded-full bg-secondary"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              </FadeIn>
            );
          })}
        </div>
      </div>
    </section>
  );
}
