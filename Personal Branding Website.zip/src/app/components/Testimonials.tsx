import { FadeIn } from './FadeIn';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Maria Silva',
    role: 'Família acompanhada',
    text: 'Rafaela nos acompanhou em um dos momentos mais delicados de nossas vidas. Sua presença trouxe conforto, dignidade e paz para toda a família durante a transição.',
    rating: 5
  },
  {
    name: 'João Santos',
    role: 'Aluno da formação',
    text: 'A formação com Rafaela transformou minha prática terapêutica. Aprendi a integrar técnica com sensibilidade e a honrar o processo de cada pessoa.',
    rating: 5
  },
  {
    name: 'Ana Paula',
    role: 'Cliente de terapia',
    text: 'O processo terapêutico me levou a um profundo autoconhecimento. Rafaela me ajudou a ressignificar questões importantes e encontrar meu próprio caminho.',
    rating: 5
  }
];

export function Testimonials() {
  return (
    <section id="depoimentos" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <FadeIn>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl text-primary mb-4">
            Depoimentos
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            O que as pessoas dizem sobre o trabalho desenvolvido
          </p>
          </div>
        </FadeIn>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <FadeIn key={testimonial.name} delay={index * 0.1}>
            <div
              key={testimonial.name}
              className="bg-accent/30 rounded-2xl p-8 relative hover:shadow-lg transition-shadow"
            >
              <Quote className="absolute top-6 right-6 text-secondary/30" size={48} />

              <div className="relative z-10">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <svg
                      key={i}
                      className="w-5 h-5 fill-secondary"
                      viewBox="0 0 20 20"
                    >
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                    </svg>
                  ))}
                </div>

                <p className="text-foreground/80 mb-6 leading-relaxed italic">
                  "{testimonial.text}"
                </p>

                <div>
                  <p className="text-primary">
                    {testimonial.name}
                  </p>
                  <p className="text-sm text-foreground/60">
                    {testimonial.role}
                  </p>
                </div>
              </div>
            </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
