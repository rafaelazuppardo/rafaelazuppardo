import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <nav className="container mx-auto px-4 md:px-6 py-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => scrollToSection('hero')}
            className="text-xl md:text-2xl tracking-tight text-primary hover:text-secondary transition-colors"
          >
            Rafaela Zuppardo
          </button>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 text-primary"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          <div className="hidden md:flex gap-8">
            <button onClick={() => scrollToSection('sobre')} className="text-foreground hover:text-secondary transition-colors">
              Sobre
            </button>
            <button onClick={() => scrollToSection('atuacao')} className="text-foreground hover:text-secondary transition-colors">
              Áreas de Atuação
            </button>
            <button onClick={() => scrollToSection('cursos')} className="text-foreground hover:text-secondary transition-colors">
              Cursos
            </button>
            <button onClick={() => scrollToSection('depoimentos')} className="text-foreground hover:text-secondary transition-colors">
              Depoimentos
            </button>
            <button onClick={() => scrollToSection('contato')} className="text-foreground hover:text-secondary transition-colors">
              Contato
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden pt-4 pb-2 flex flex-col gap-4">
            <button onClick={() => scrollToSection('sobre')} className="text-left text-foreground hover:text-secondary transition-colors">
              Sobre
            </button>
            <button onClick={() => scrollToSection('atuacao')} className="text-left text-foreground hover:text-secondary transition-colors">
              Áreas de Atuação
            </button>
            <button onClick={() => scrollToSection('cursos')} className="text-left text-foreground hover:text-secondary transition-colors">
              Cursos
            </button>
            <button onClick={() => scrollToSection('depoimentos')} className="text-left text-foreground hover:text-secondary transition-colors">
              Depoimentos
            </button>
            <button onClick={() => scrollToSection('contato')} className="text-left text-foreground hover:text-secondary transition-colors">
              Contato
            </button>
          </div>
        )}
      </nav>
    </header>
  );
}
