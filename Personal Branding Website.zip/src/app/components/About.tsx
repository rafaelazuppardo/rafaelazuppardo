import { ImageWithFallback } from './ImageWithFallback';
import { FadeIn } from './FadeIn';
import { Heart, BookOpen, Award } from 'lucide-react';

export function About() {
  return (
    <section id="sobre" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <FadeIn>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="relative order-2 md:order-1">
            <div className="absolute inset-0 bg-accent rounded-3xl transform -rotate-3"></div>
            <div className="relative rounded-3xl overflow-hidden shadow-xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1506126613408-eca07ce68773?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxob2xpc3RpYyUyMHRoZXJhcHklMjB3ZWxsbmVzcyUyMGhlYWxpbmd8ZW58MXx8fHwxNzc5NjU0OTgwfDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Momento de meditação e autocuidado"
                className="w-full aspect-[4/3] object-cover"
              />
            </div>
          </div>

          <div className="space-y-6 order-1 md:order-2">
            <h2 className="text-3xl md:text-4xl text-primary">
              Sobre Mim
            </h2>

            <p className="text-lg leading-relaxed text-foreground/80">
              Acredito que o verdadeiro cuidado começa pelo autoconhecimento. Através de
              terapias integrativas e práticas de desenvolvimento pessoal, acompanho pessoas
              em suas jornadas de transformação interior e crescimento.
            </p>

            <p className="text-base leading-relaxed text-foreground/70">
              Como terapeuta e doula de fim de vida, trabalho com uma abordagem holística
              que integra corpo, mente e espírito. Como educadora, formo profissionais que
              desejam atuar com consciência, sensibilidade e respeito aos processos únicos
              de cada ser.
            </p>

            <div className="space-y-4 pt-4">
              <div className="flex gap-4 items-start">
                <div className="p-3 bg-accent rounded-lg shrink-0">
                  <Heart className="text-primary" size={24} />
                </div>
                <div>
                  <h4 className="text-primary mb-1">Abordagem Integrativa</h4>
                  <p className="text-sm text-foreground/70">Cuidado que honra a integralidade do ser humano em todas as suas dimensões</p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="p-3 bg-accent rounded-lg shrink-0">
                  <Award className="text-primary" size={24} />
                </div>
                <div>
                  <h4 className="text-primary mb-1">Desenvolvimento Pessoal</h4>
                  <p className="text-sm text-foreground/70">Facilitação de processos de autoconhecimento e transformação interior</p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="p-3 bg-accent rounded-lg shrink-0">
                  <BookOpen className="text-primary" size={24} />
                </div>
                <div>
                  <h4 className="text-primary mb-1">Formação Profissional</h4>
                  <p className="text-sm text-foreground/70">Capacitação de terapeutas e cuidadores em práticas conscientes</p>
                </div>
              </div>
            </div>
          </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
