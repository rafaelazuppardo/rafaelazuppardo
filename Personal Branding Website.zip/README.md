
  # Personal Branding Website

  This is a code bundle for Personal Branding Website. The original project is available at https://www.figma.com/design/J9hr5WFxXAYITiz4RArAxG/Personal-Branding-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  